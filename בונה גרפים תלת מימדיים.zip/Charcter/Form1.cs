﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Graphs
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int size = 100;
        double zoom = 5;
        double resoulution = 1;
        double sharpness = 1;
        double[,] XArr;
        double[,] YArr;
        double[,] ZArr;
        double[,] newXArr;
        double[,] newYArr;
        double maxH;
        double minH;
        double diffrence, color;
        double radian;
        double boardAngleX = 60, boardAngleY = 60;
        Graphics g;
        float h;
        float w;
        string eqaution = "";
        int lineFreq = 10;
        static Random rand = new Random();
        /**
         הפונקציה אחראית על ניקוי הלוח מהדפסות קודמות.
         קלט:
             אין
         פלט:
             אין
         */
        private void clearBoard()
        {
            panel1.Enabled = false;
            panel1.Controls.Clear();
            panel1.Enabled = true;
        }
        /**
         הפונקציה מחזירה משוואה אשר שמורה בתוך עץ בינארי, 
         אשר מבטאת את ההשתנות של כמה כחול\אדום\ירוק הגרף על פי הגובה היחסי של הנקודה. 
         buildTree() היא עושה זאת באמצעות בדיקה של איזה קופסאות מסומנות וקריאה לפונקציה 
         קלט:
            מסמל איזה צבע הפונקציה שתוחזר צריכה לסמל - "green"או ל"blue"או ל "red" ששווה או ל String  
         פלט:
            buildTree() אשר יכיל את הפונקציה ויבנה באמצעות,string עץ בינארי המכיל 
         */
        private BinTreeNode<string> colorEqation(string color)
        {
            string str = "0";
            if (color == "red")
            {
                if (chkbox_HighRed.Checked == true || chkbox_HighYellow.Checked || chkbox_HighPink.Checked || chkbox_HighWhite.Checked)
                {
                    str = "x";
                }
                if (chkbox_LowRed.Checked == true || chkbox_LowYellow.Checked || chkbox_LowPink.Checked || chkbox_LowWhite.Checked)
                {
                    if (str == "0")
                        str = "255-x";
                    else
                        str = "255";
                }
            }
            else if (color == "green")
            {
                if (chkbox_HighGreen.Checked == true || chkbox_HighCyan.Checked || chkbox_HighYellow.Checked || chkbox_HighWhite.Checked)
                {
                    str = "x";
                }
                if (chkbox_LowGreen.Checked == true || chkbox_LowCyan.Checked || chkbox_LowYellow.Checked || chkbox_LowWhite.Checked)
                {
                    if (str == "0")
                        str = "255-x";
                    else
                        str = "255";
                }
            }
            else if (color == "blue")
            {
                if (chkbox_HighBlue.Checked == true || chkbox_HighCyan.Checked || chkbox_HighPink.Checked || chkbox_HighWhite.Checked)
                {
                    str = "x";
                }
                if (chkbox_LowBlue.Checked == true || chkbox_LowCyan.Checked || chkbox_LowPink.Checked || chkbox_LowWhite.Checked)
                {
                    if (str == "0")
                        str = "255-x";
                    else
                        str = "255";
                }
            }
            return BuildTree(str);
        }
        /**
         ,הפונקציה בונה בצורה יחסית אקראית משוואה מתמטית אשר מבטאת את ההשתנות של כמה כחול\אדום\ירוק הגרף על פי הגובה היחסי של הנקודה
         .כך שהתוצאה של חישוב הפונקציה חדשה תהיה בין 0 ל255
         .buildTree() שמומר בסוף לעץ בינארי באמצעות הפונקציה stringהיא עושה זאת באמצעות שימוש במשתנה רנדומלי ו
         קלט:
            אין
         פלט:
            .buildTree() אשר יכיל את הפונקציה ויבנה באמצעות ,string עץ בינארי המכיל 
         */
        private BinTreeNode<string> randomColorEqation()
        {
            if (rand.Next(3) == 0)
            {
                if (rand.Next(3) == 0)
                    return BuildTree(rand.Next(1, 255).ToString());
                else
                    return BuildTree((rand.Next(2) * 255).ToString());
            }
            else
            {
                if (rand.Next(2) == 0)
                {
                    if (rand.Next(4) != 0)
                        return BuildTree("x");
                    else
                        return BuildTree("(x*" + rand.Next(2, 5).ToString()+")%256");
                }
                else
                {
                    if (rand.Next(2) == 0)
                    {
                        if (rand.Next(4) != 0)
                            return BuildTree("(x+" + rand.Next(255).ToString() + ")%256");
                        else
                            return BuildTree("(x*"  +rand.Next(2, 5).ToString() +"+" + rand.Next(255).ToString()+")%256");
                    }
                    else
                    {
                        if (rand.Next(4) != 0)
                        {
                            if (rand.Next(2) == 0)
                                return BuildTree("abs("+rand.Next(254).ToString()+"-x)%256");
                            else
                                return BuildTree("255-x");
                        }
                        else
                        {
                            if (rand.Next(2) == 0)
                                return BuildTree("abs(" + rand.Next(254).ToString() + "-x*" + rand.Next(2, 5).ToString() + ")%256");
                            else
                                return BuildTree("abs(255-x*" + rand.Next(2, 5).ToString() + ")%256");
                        }
                    }
                }
            }
        }
        /**
         ,הפונקציה אחראית על בניית הגרף שמייצג את הפונקציה שהמשתמש הכניס
         הביאה NewDiemnsions באמצעות הנתונים הפומביים שהפונקציה 
         היא יוצרת מרובעים בין נקודת סמוכות בצבעים המשתנים לפי הגובה היחסי של הריבוע
         .CalculateBinTree וחישוב הצבע באמצעות הפונקציה המתארת את הצבע שנוצרה מקודם וקריאה לפונקציה
         .במידה והקופסה של הקווים מסומנת היא גם תדפיס רשת קווים בצבע נגטיבי מצבעם של המרובעים שהם עומדים עליהם
         קלט:
            אין
         פלט:
            אין
         */
        private void DrawFigure()
        {
            Point p1, p2, p3, p4;
            Point[] points;
            SolidBrush brush;
            BinTreeNode<string> redEqation;
            BinTreeNode<string> greenEqation;
            BinTreeNode<string> blueEqation;
            if (chkbox_RandColor.Checked == true)
            {
                do
                {
                    redEqation = randomColorEqation();
                    greenEqation = randomColorEqation();
                    blueEqation = randomColorEqation();
                } while (redEqation.GetRight() == null && redEqation.GetInfo() != "x" && greenEqation.GetRight() == null && greenEqation.GetInfo() != "x" && blueEqation.GetRight() == null && blueEqation.GetInfo() != "x");
            }
            else
            {
                redEqation = colorEqation("red");
                greenEqation = colorEqation("green");
                blueEqation = colorEqation("blue");
            }
            if (chkbox_Lines.Checked == true)
            {
                Pen pen = new Pen(Color.Black, 1);
                if (chkbox_ThickLines.Checked == true)
                    pen.Width = 3;
                for (int j = size - 2; j >= 0; j--)
                {
                    for (int i = size - 2; i >= 0; i--)
                    {
                        color = (ZArr[i + 1, j] - minH) / diffrence * 255;
                        brush = new SolidBrush(Color.FromArgb(255, (int)(CalculateBinTree(redEqation, color, 0)), (int)(CalculateBinTree(greenEqation, color, 0)), (int)(CalculateBinTree(blueEqation, color, 0))));
                        p1 = new Point((int)(w + newXArr[i, j] * zoom), (int)(h - newYArr[i, j] * zoom));
                        p2 = new Point((int)(w + newXArr[i, j + 1] * zoom), (int)(h - newYArr[i, j + 1] * zoom));
                        p3 = new Point((int)(w + newXArr[i + 1, j + 1] * zoom), (int)(h - newYArr[i + 1, j + 1] * zoom));
                        p4 = new Point((int)(w + newXArr[i + 1, j] * zoom), (int)(h - newYArr[i + 1, j] * zoom));
                        points = new Point[] { p1, p2, p3, p4 };
                        g.FillPolygon(brush, points);
                        if ((j + 1) % lineFreq == (size - 2) % lineFreq)
                        {
                            pen.Color = Color.FromArgb(255, (int)(255 - CalculateBinTree(redEqation, (ZArr[i + 1, j + 1] - minH) / diffrence * 255, 0)), (int)(255 - CalculateBinTree(greenEqation, (ZArr[i + 1, j + 1] - minH) / diffrence * 255, 0)), (int)(255 - CalculateBinTree(blueEqation, (ZArr[i + 1, j + 1] - minH) / diffrence * 255, 0)));
                            g.DrawLine(pen, (float)(w + newXArr[i, j + 1] * zoom), (float)(h - newYArr[i, j + 1] * zoom), (float)(w + newXArr[i + 1, j + 1] * zoom), (float)(h - newYArr[i + 1, j + 1] * zoom));
                        }
                        else if (j == 0)
                        {
                            pen.Color = Color.FromArgb(255, (int)(255 - CalculateBinTree(redEqation, color, 0)), (int)(255 - CalculateBinTree(greenEqation, color, 0)), (int)(255 - CalculateBinTree(blueEqation, color, 0)));
                            g.DrawLine(pen, (float)(w + newXArr[i, 0] * zoom), (float)(h - newYArr[i, 0] * zoom), (float)(w + newXArr[i + 1, 0] * zoom), (float)(h - newYArr[i + 1, 0] * zoom));
                        }
                        if ((i + 1) % lineFreq == (size - 2) % lineFreq)
                        {
                            pen.Color = Color.FromArgb(255, (int)(255 - CalculateBinTree(redEqation, (ZArr[i + 1, j + 1] - minH) / diffrence * 255, 0)), (int)(255 - CalculateBinTree(greenEqation, (ZArr[i + 1, j + 1] - minH) / diffrence * 255, 0)), (int)(255 - CalculateBinTree(blueEqation, (ZArr[i + 1, j + 1] - minH) / diffrence * 255, 0)));
                            g.DrawLine(pen, (float)(w + newXArr[i + 1, j] * zoom), (float)(h - newYArr[i + 1, j] * zoom), (float)(w + newXArr[i + 1, j + 1] * zoom), (float)(h - newYArr[i + 1, j + 1] * zoom));
                        }
                        else if (i == 0)
                        {
                            pen.Color = Color.FromArgb(255, (int)(255 - CalculateBinTree(redEqation, color, 0)), (int)(255 - CalculateBinTree(greenEqation, color, 0)), (int)(255 - CalculateBinTree(blueEqation, color, 0)));
                            g.DrawLine(pen, (float)(w + newXArr[0, j] * zoom), (float)(h - newYArr[0, j] * zoom), (float)(w + newXArr[0, j + 1] * zoom), (float)(h - newYArr[0, j + 1] * zoom));
                        }
                    }
                }
            }
            else
            {
                for (int j = size - 2; j >= 0; j--)
                {
                    for (int i = size - 2; i >= 0; i--)
                    {
                        color = (ZArr[i, j] - minH) / diffrence * 255;
                        brush = new SolidBrush(Color.FromArgb(255, (int)(CalculateBinTree(redEqation, color, 0)), (int)(CalculateBinTree(greenEqation, color, 0)), (int)(CalculateBinTree(blueEqation, color, 0))));
                        p1 = new Point((int)(w + newXArr[i, j] * zoom), (int)(h - newYArr[i, j] * zoom));
                        p2 = new Point((int)(w + newXArr[i, j + 1] * zoom), (int)(h - newYArr[i, j + 1] * zoom));
                        p3 = new Point((int)(w + newXArr[i + 1, j + 1] * zoom), (int)(h - newYArr[i + 1, j + 1] * zoom));
                        p4 = new Point((int)(w + newXArr[i + 1, j] * zoom), (int)(h - newYArr[i + 1, j] * zoom));
                        points = new Point[] { p1, p2, p3, p4 };
                        g.FillPolygon(brush, points);
                    }
                }
            }
        }
        /**
         ,הפונקציה אחראית על המרת הנתונים התלת מימדיים לנתונים דו מימדיים
         .אשר מייצגים ונראים כאשר מדפיסים אותם כמו נתונים תלת מימדיים
         .היא עושה זאת באמצעות משוואה מתמטית וידיעה של זווית הנטייה של הציר האופקי והאנכי
         קלט:
            אין
         פלט:
            אין
         */
        private void NewDiemnsions() 
        {
            if (chkbox_Height.Checked == true)
            {
                for (int i = 0; i < XArr.GetLength(0); i++)
                {
                    for (int j = 0; j < XArr.GetLength(1); j++)
                    {
                        newXArr[i, j] = XArr[i, j] + ((Math.Cos(boardAngleX) * YArr[i, j]) * 0.5);
                        newYArr[i, j] = ZArr[i, j] + ((Math.Sin(boardAngleY) * YArr[i, j]) * 0.5);
                    }
                }
            }
            else
            {
                for (int i = 0; i < XArr.GetLength(0); i++)
                {
                    for (int j = 0; j < XArr.GetLength(1); j++)
                    {
                        newXArr[i, j] = XArr[i, j] + ((Math.Cos(boardAngleX) * ZArr[i, j]) * 0.5);
                        newYArr[i, j] = YArr[i, j] + ((Math.Sin(boardAngleY) * ZArr[i, j]) * 0.5);
                    }
                }
            }
        }
        /**
        .הפונקציה אשר עולה כאשר טוענים את התוכנית בהתחלה, לפני שהתוכנית עוד עלתה
         היא אחראית על נתינת ערכים התחלתיים למשתנים מסוימים ועל הוספת הפונקציות המוכנות מראש
         .שבו מכניסים ואנו בוחרים בפונקציות שיודפסו מאוחר יותר combo boxל
         קלט:
            EventArgs e - שמכיל את הפרטים של האירוע EventArgs משתנה מסוג
            Object Sender - פרמטר שמכיל לאובייקט שקרא לפונקציה זו
         פלט:
            אין
         */
        private void Form1_Load(object sender, EventArgs e)
        {
            chkbox_LowBlack.Checked = true;
            chkbox_HighCyan.Checked = true;
            chkbox_Resoulution.Checked = true;
            chkbox_Height.Checked = true;
            radian = 180 / Math.PI;
            boardAngleX /= radian;
            boardAngleY /= radian;
            g = panel1.CreateGraphics();
            h = panel1.Height / 2;
            w = panel1.Width / 2;
            cmbox_Eqation.Items.Add("x^2+y^2-40");
            cmbox_Eqation.Items.Add("x^2-y^2");
            cmbox_Eqation.Items.Add("x^2*y^2-20");
            cmbox_Eqation.Items.Add("sin(x)");
            cmbox_Eqation.Items.Add("cos(x)+cos(y)^2");
            cmbox_Eqation.Items.Add("cos(x^2+y^2)");
            cmbox_Eqation.Items.Add("sin(x^2+y^2)");
            cmbox_Eqation.Items.Add("1/(x^2+y^2)");
            cmbox_Eqation.Items.Add("abs(cos(x)+cos(y))^0.5");
            cmbox_Eqation.Items.Add("cos(x)+cos(y)");
            cmbox_Eqation.Items.Add("abs(cos(x^2+y^2))^0.5");
            cmbox_Eqation.Items.Add("abs(cos(x+y))^0.5");
            cmbox_Eqation.Items.Add("cos(abs(x)+abs(y))*(x+y)");
            cmbox_Eqation.Items.Add("cos(abs(x)+abs(y))*(abs(x)+abs(y))");
            cmbox_Eqation.Items.Add("cos(abs(x)+abs(y))");
            cmbox_Eqation.Items.Add("abs(sin(x)*(sin(x)+cos(y)))^0.2");
            cmbox_Eqation.Items.Add("sin(x^2)+cos(y^2)");
            cmbox_Eqation.Items.Add("x*(y^3)-y*(x^3)");
            cmbox_Eqation.Items.Add("(x^2+y^2)^0.5-15");
            cmbox_Eqation.Items.Add("20-abs(x+y)-abs(y-x)");
            cmbox_Eqation.Items.Add("abs(sin(x)*(sin(y)+cos(x)))^0.2");
        }
        /**
         .הפונקציה שנקראת לאחר לחיצה על הכפתור שמסמן להתחיל את תהליך בניית הגרף
         .הפונקציה אחראית על כל התהליך של בניית הגרף, מההתחלה עד סופו
         .(היא קובעת למערכים שמכילים את הנתונים על הנקודות את גודלם(כמות הנקודות
         ,stringובונה עץ שיכיל את הפונקציה מה ,combo boxשמייצג את הפונקציה שהמשתמש רוצה להציג, מה string על קבלת 
         .buildTree() אחרי שמחקה רווחים והפכה את האותיותבו לאותית קטנות - לפונקציה combo boxשקיבלה מה stringבאמצעות שליחת ה
         z של כל נקודה ומחשבת את הערך של yו x לאחר מכן היא מחשבת על פי הרזולוציה ואו טווח הערכים את הערך של
         .CalculateBinTree של כל נקודה באמצעות קריאה לפונקציה
         ,הגבוה ביותר והנמוך ביותר וההבדל ביניהם zבנוסף היא אחראית על מציאת ערך ה
         .כדי שיהיה ניתן לראות מהו הגובה היחסי של כל נקודה ביחס לערכים אלו
         .כדי שיהיה קל יותר להציג את הפונקציה בלי קשר לטווח הערכים שהפונקציה מייצגת z ערכים שונים מהקודמים שהיא השתמשה לחישוב הערך של yול xהיא נותנת ל
         NewDiemnsions() היא אחראית על "היפוך הנתונים" במידה ואחת מהקופסאות של היפוך צירים מסומנת. לאחר מכן היא קוראת לפונקציה 
         .שתמיר את הערכים התלת מימדיים לדו מימדיים כדי שיהיה ניתן להדפיס את הגרף
         .שתדפיז את הגרף DrawFigure() לאחר מכן היא קוראת לפונקציה
         .היא אחראית גם על מניעה מקריסה של התוכנית בכל אחד משלבים אלו וסימון הדבר אשר היה אמור לגרום לתוכנית לקרוס במידה והיא הייתה אמורה לקרוס
         קלט:
            EventArgs e - שמכיל את הפרטים של האירוע EventArgs משתנה מסוג
            Object Sender - פרמטר שמכיל לאובייקט שקרא לפונקציה זו
         פלט:
            אין
         */
        private void btn_BuildGraph_Click(object sender, EventArgs e)
        {
            cmbox_Eqation.BackColor = Color.White;
            cmbox_Eqation.ForeColor = Color.Black;
            txtbox_RangeFrom.BackColor = Color.White;
            txtbox_RangeFrom.ForeColor = Color.Black;
            txtbox_RangeTo.BackColor = Color.White;
            txtbox_RangeTo.ForeColor = Color.Black;
            XArr = new double[size, size];
            YArr = new double[size, size];
            ZArr = new double[size, size];
            newXArr = new double[size, size];
            newYArr = new double[size, size];
            maxH = double.MinValue;
            minH = double.MaxValue;
            eqaution = cmbox_Eqation.Text;
            double temp;
            try
            {
                BinTreeNode<string> eqautionTree = BuildTree(FixSpaces(eqaution).ToLower());
                if (chkbox_Resoulution.Checked == true)
                {
                    for (int i = 0; i < size; i++)
                    {
                        for (int j = 0; j < size; j++)
                        {
                            XArr[i, j] = (i - (size / 2)) * resoulution;
                            YArr[i, j] = (j - (size / 2)) * resoulution;
                        }
                    }
                }
                else
                {
                    double To = double.Parse(txtbox_RangeTo.Text);
                    double From = double.Parse(txtbox_RangeFrom.Text);
                    for (int i = 0; i < size; i++)
                    {
                        for (int j = 0; j < size; j++)
                        {
                            XArr[i, j] = i * ((To - From) / size) + From;
                            YArr[i, j] = j * ((To - From) / size) + From;
                        }
                    }
                }
                for (int i = 0; i < size; i++)
                {
                    for (int j = 0; j < size; j++)
                    {
                        ZArr[i, j] = CalculateBinTree(eqautionTree, XArr[i, j], YArr[i, j]) * sharpness;
                        if (chkbox_FlipZ.Checked == true)
                            ZArr[i, j] *= (-1);
                        if (double.IsInfinity(ZArr[i, j])|| double.IsNaN(ZArr[i, j]))
                            ZArr[i, j] = 0;
                        if (ZArr[i, j] > maxH)
                            maxH = ZArr[i, j];
                        if (ZArr[i, j] < minH)
                            minH = ZArr[i, j];
                    }
                }
                for (int i = 0; i < size; i++)
                {
                    for (int j = 0; j < size; j++)
                    {
                        XArr[i, j] = i - (size / 2);
                        YArr[i, j] = j - (size / 2);
                    }
                }
                if (chkbox_FlipX.Checked == true)
                {
                    for (int i = 0; i < size / 2; i++)
                    {
                        for (int j = 0; j < size; j++)
                        {
                            temp = ZArr[i, j];
                            ZArr[i, j] = ZArr[size - 1 - i, j];
                            ZArr[size - 1 - i, j] = temp;
                        }
                    }
                }
                if (chkbox_FlipY.Checked == true)
                {
                    for (int i = 0; i < size; i++)
                    {
                        for (int j = 0; j < size / 2; j++)
                        {
                            temp = ZArr[i, j];
                            ZArr[i, j] = ZArr[i, size - 1 - j];
                            ZArr[i, size - 1 - j] = temp;
                        }
                    }
                }
                diffrence = maxH - minH;
                if (diffrence == 0.0)
                    diffrence = 0.1;
                clearBoard();
                NewDiemnsions();
                DrawFigure();
            }
            catch
            {
                try
                {
                    double tempCheack = double.Parse(txtbox_RangeFrom.Text);
                }
                catch
                {
                    txtbox_RangeFrom.BackColor = Color.Red;
                    txtbox_RangeFrom.ForeColor = Color.White;
                }
                try
                {
                    double tempCheack = double.Parse(txtbox_RangeTo.Text);
                }
                catch
                {
                    txtbox_RangeTo.BackColor = Color.Red;
                    txtbox_RangeTo.ForeColor = Color.White;
                }
                try
                {
                    DrawFigure();
                }
                catch
                {
                    cmbox_Eqation.BackColor = Color.Red;
                    cmbox_Eqation.ForeColor = Color.White;
                }
                clearBoard();
                MessageBox.Show("Unvalid equation or values\nPlease try again");
            }
        }
        /**
        .שמתאר פונקציה ואו משוואה מתמטית אל תוך עץ בינארי, תוך כדי התחשבות בסוגריים וסדר פעולות string פונקציה זו אחראית על הכנסת נתונים שמכיל 
         pre order בונה את העץ הבינארי על פי שיטת
         קלט:
            שמתאר פונקציה או משוואה מתמטית string
         פלט:
            עץ בינארי המכיל את הנתונים של הפונקציה ואו המשוואה שקיבל בתור קלט
         */
        private BinTreeNode<string> BuildTree(string str)
        {
            BinTreeNode<string> binTree = null;
            string temp;
            bool booltemp = false;
            int a = 0;
            if (str[str.Length - 1] == ')')
                booltemp = true;
            for (int i = str.Length - 1; i >= 0; i--)
            {
                if (str[i] == ')')
                    a++;
                else if (str[i] == '(')
                {
                    a--;
                    if (booltemp == true && a == 0)
                    {
                        if (i == 0)
                            return (BuildTree(str.Substring(1, str.Length - 2)));
                        else
                            booltemp = false;
                    }
                }
                else if ((str[i] == '-' || str[i] == '+') && binTree == null && a == 0 && i != 0 && i < str.Length - 1)
                {
                    binTree = new BinTreeNode<string>(str[i].ToString());
                    binTree.SetLeft(BuildTree(str.Substring(0, i)));
                    binTree.SetRight(BuildTree(str.Substring(i + 1, str.Length - i - 1)));
                }
            }
            if (str[0] == '-' || str[0] == '+')
                return BuildTree("0" + str);
            a = 0;
            for (int i = str.Length - 1; i >= 0; i--)
            {
                if (str[i] == ')')
                    a++;
                else if (str[i] == '(')
                    a--;
                else if ((str[i] == '*' || str[i] == '/' || str[i] == '%') && binTree == null && a == 0)
                {
                    binTree = new BinTreeNode<string>(str[i].ToString());
                    binTree.SetLeft(BuildTree(str.Substring(0, i)));
                    binTree.SetRight(BuildTree(str.Substring(i + 1, str.Length - i - 1)));
                }
            }
            a = 0;
            for (int i = str.Length - 1; i >= 0; i--)
            {
                if (str[i] == ')')
                    a++;
                else if (str[i] == '(')
                    a--;
                else if (str[i] == '^' && binTree == null && a == 0)
                {
                    binTree = new BinTreeNode<string>(str[i].ToString());
                    binTree.SetLeft(BuildTree(str.Substring(0, i)));
                    binTree.SetRight(BuildTree(str.Substring(i + 1, str.Length - i - 1)));
                }
                else if (i >= 3 && binTree == null && a == 0)
                {
                    temp = str.Substring(i - 3, 4);
                    if (temp == "sqrt")
                    {
                        binTree = new BinTreeNode<string>(temp);
                        binTree.SetRight(BuildTree(str.Substring(i + 1, str.Length - i - 1)));
                    }

                }
            }
            a = 0;
            for (int i = str.Length - 1; i >= 2; i--)
            {
                if (str[i] == ')')
                    a++;
                else if (str[i] == '(')
                    a--;
                else if (binTree == null && a == 0)
                {
                    temp = str.Substring(i - 2, 3);
                    if (temp == "sin" || temp == "cos" || temp == "tan" || temp == "abs")
                    {
                        binTree = new BinTreeNode<string>(temp);
                        binTree.SetRight(BuildTree(str.Substring(i + 1, str.Length - i - 1)));
                    }
                }
            }
            if (binTree == null)
                return (new BinTreeNode<string>(str));
            return binTree;
        }
        /**
         .פונקצייה זו אחראית על חישוב התוצאה של הפונקציה שהיא מקבלת בתוך עץ בינארי כקלט, והחזרת התוצאה לפונקציה שקראה לה
         .כקלט yו x באמצעות קבלת הערך של yו x היא יכולה גם לחשב את התוצאה של משוואות עם משתנים בשם
         .post order הסריקה של העץ בינארי למטרת החישוב מתבצעת בשיטת
         קלט:
            עץ בינארי שמכיל את  המשוואה שהפונקציה צריכה לפתור
            .y ושל x שמכילים את הערך של doubles שני 
         פלט:
            שמכיל את התוצאה של חישוב המשוואה double 
         */
        private double CalculateBinTree(BinTreeNode<string> binTree, double x, double y)
        {
            if (binTree != null)
            {
                if (binTree.GetInfo() == "+")
                    return (CalculateBinTree(binTree.GetLeft(), x, y) + CalculateBinTree(binTree.GetRight(), x, y));
                else if (binTree.GetInfo() == "-")
                    return (CalculateBinTree(binTree.GetLeft(), x, y) - CalculateBinTree(binTree.GetRight(), x, y));
                else if (binTree.GetInfo() == "*")
                    return (CalculateBinTree(binTree.GetLeft(), x, y) * CalculateBinTree(binTree.GetRight(), x, y));
                else if (binTree.GetInfo() == "/")
                    return (CalculateBinTree(binTree.GetLeft(), x, y) / CalculateBinTree(binTree.GetRight(), x, y));
                else if (binTree.GetInfo() == "%")
                    return (CalculateBinTree(binTree.GetLeft(), x, y) % CalculateBinTree(binTree.GetRight(), x, y));
                else if (binTree.GetInfo() == "^")
                    return (Math.Pow(CalculateBinTree(binTree.GetLeft(), x, y), CalculateBinTree(binTree.GetRight(), x, y)));
                else if (binTree.GetInfo() == "sqrt")
                    return (Math.Sqrt(CalculateBinTree(binTree.GetRight(), x, y)));
                else if (binTree.GetInfo() == "sin")
                    return (Math.Sin(CalculateBinTree(binTree.GetRight(), x, y) / radian));
                else if (binTree.GetInfo() == "cos")
                    return (Math.Cos(CalculateBinTree(binTree.GetRight(), x, y) / radian));
                else if (binTree.GetInfo() == "tan")
                    return (Math.Tan(CalculateBinTree(binTree.GetRight(), x, y) / radian));
                else if (binTree.GetInfo() == "abs")
                    return (Math.Abs(CalculateBinTree(binTree.GetRight(), x, y)));
                else if (binTree.GetInfo() == "x")
                    return (x);
                else if (binTree.GetInfo() == "y")
                    return (y);
                else if (binTree.GetInfo() == "-x")
                    return (-x);
                else if (binTree.GetInfo() == "-y")
                    return (-y);
            }
            return (double.Parse(binTree.GetInfo()));
        }
        /**
         פונקציה אשר מקבלת כקלט טקסט עם רווחים ומחזירה את אותו הטקסט בלי רווחים
         קלט:
            כלשהו string כל
         פלט:
            .שהפונקציה קיבלה אך בלי הרווחים במידה והיו רווחים stringה
         */
        private string FixSpaces(string str)
        {
            for (int i = str.Length - 1; i >= 0; i--)
                if (str[i] == ' ')
                {
                    str = str.Substring(0, i) + str.Substring(i + 1, str.Length - i - 1);
                    i++;
                }
            return (str);
        }
        /**
         .כל הפונקציות שרשומות כאן למטה אחראיות על להכניס למשתנה שהם משפיעות עליו ערך כאשר מזיזים את הגורר שקורה לפונקציות אלו
         .שנמצא ליד הגורר שקורא להן text boxבנוסף פונקציות אלו אחראיות על הצגת הערך של המשתנה שהן משפיעות עליו ב
         קלט:
            EventArgs e - שמכיל את הפרטים של האירוע EventArgs משתנה מסוג
            Object Sender - פרמטר שמכיל לאובייקט שקרא לפונקציה זו
         פלט:
            אין
         */
        private void trkbar_Sharpness_Scroll(object sender, EventArgs e)
        {
            sharpness = trkbar_Sharpness.Value;
            if (sharpness < 1)
                sharpness = 1 + (sharpness-1) * 0.05;
            txtbox_Sharpness.Text = sharpness.ToString();
        }
        private void trkbar_Size_Scroll(object sender, EventArgs e)
        {
            size = trkbar_Size.Value;
            txtbox_Size.Text = size.ToString();
            trkbar_Lines.Maximum = size / 2 - 1;
        }
        private void trkbar_Zoom_Scroll(object sender, EventArgs e)
        {
            zoom = trkbar_Zoom.Value;
            if (zoom < 1)
                zoom = 1 + (zoom - 1) * 0.25;
            else if (zoom > 10)
                zoom = 10 + (zoom - 10) * 5;
            txtbox_Zoom.Text = zoom.ToString();
        }
        private void trkbar_Resoulution_Scroll(object sender, EventArgs e)
        {
            resoulution = Math.Pow(1.6, trkbar_Resoulution.Value*(-1));
            txtbox_Resoulution.Text = resoulution.ToString();
            txtbox_RangeFrom.Text = ((size / 2) * (-1) * resoulution).ToString();
            txtbox_RangeTo.Text = ((size / 2 - 1) * resoulution).ToString();
        }
        private void trkbar_XAngle_Scroll(object sender, EventArgs e)
        {
            boardAngleX = trkbar_XAngle.Value;
            boardAngleX /= radian;
            txtbox_XAngle.Text = trkbar_XAngle.Value.ToString();
        }
        private void trkbar_YAngle_Scroll(object sender, EventArgs e)
        {
            boardAngleY = trkbar_YAngle.Value;
            boardAngleY /= radian;
            txtbox_YAngle.Text = trkbar_YAngle.Value.ToString();
        }
        private void trkbar_Lines_Scroll(object sender, EventArgs e)
        {
            lineFreq = trkbar_Lines.Maximum - trkbar_Lines.Value + 1;
            txtbox_Lines.Text = lineFreq.ToString();
        }
        /**
         ."פונקציה זו נקראת כאשר משנים את הסימון בתיבה שרשום לידה "רשת קווים
         ,כאשר מסמנים את תיבה זו הפונקציה אחראית על לאפשר להזיז את הגורר שאחראי על תכיפות הקווים
         .ולאפשר סימון של התיבה שאחראית על האם הקווים יהיו עבים או לא
         ,במידה ומורידים את הסימון מתיבה זו אז פונקציה זו אחראית על להוריד את הסימון מהתיבה שאחראית על האם הקווים יהיו עבים או לא
         .לנטרל את האפשרות לסמן את התיבה של עובי הקווים, ולנטרל את האפשרות להזיז את הגורר שאחראי על תכיפות הקווים
         קלט:
            EventArgs e - שמכיל את הפרטים של האירוע EventArgs משתנה מסוג
            Object Sender - פרמטר שמכיל לאובייקט שקרא לפונקציה זו
         פלט:
            אין
         */
        private void chkbox_Lines_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_Lines.Checked == true)
            {
                trkbar_Lines.Enabled = true;
                chkbox_ThickLines.Enabled = true;
            }
            else
            {
                trkbar_Lines.Enabled = false;
                chkbox_ThickLines.Checked = false;
                chkbox_ThickLines.Enabled = false;
            }
        }
        /**
         ,שתי פונקציות האלו נקראות כאשר משנים את הסימון בתיבות שקשורות אליהן. כל אחת מהן אחראית על להוריד את הסימון מהתיבה של השנייה במידה ומסמנים אותה
         ועל נטרול הכלים שאחראים לנתינת הערך שקשור לקופסה
         .(כלומר אם מסמנים את הרזולוציה נטרול תיבות הטקסט של טווח הערכים, ואם מסמנים טווח ערכים אז את הגורר של הרזולוציה)
         ,בנוסף כל אחת מהן אחראית על לנטרל את האפשרות לשנות את הסימן שלה אחרי שהיא מסומנת
         .ולאפשר מחדש את הסימון של התיבה השנייה – על מנת שתמיד אחת מהן תהיה מסומנת
         קלט:
            EventArgs e - שמכיל את הפרטים של האירוע EventArgs משתנה מסוג
            Object Sender - פרמטר שמכיל לאובייקט שקרא לפונקציה זו
         פלט:
            אין
         */
        private void chkbox_Resoulution_CheckedChanged(object sender, EventArgs e)
        {
            if(chkbox_Resoulution.Checked == true)
            {
                trkbar_Resoulution.Enabled = true;
                txtbox_RangeFrom.Enabled = false;
                txtbox_RangeTo.Enabled = false;
                chkbox_SizeRange.Checked = false;
                chkbox_Resoulution.Enabled = false;
                chkbox_SizeRange.Enabled = true;
            }
        }
        private void chkbox_SizeRange_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_SizeRange.Checked == true)
            {
                trkbar_Resoulution.Enabled = false;
                txtbox_RangeFrom.Enabled = true;
                txtbox_RangeTo.Enabled = true;
                chkbox_Resoulution.Checked = false;
                chkbox_SizeRange.Enabled = false;
                chkbox_Resoulution.Enabled = true;
            }
        }
        /**
         .הפונקציות למטה נקראת כאשר משנים את הסימן בתיבה שהיא קשורה אליה
         .התפקיד של כל אחת מהן הוא שכאשר מסמנים אותה להוריד את שאר הסימונים מהתיבות שקשורות לפונקציות האחרות שרשומות כאן
         .מטרתן היא לוודא שנבחר רק צבע אחד בתור צבע לנקודות הגבוהות של הגרף
         קלט:
            EventArgs e - שמכיל את הפרטים של האירוע EventArgs משתנה מסוג
            Object Sender - פרמטר שמכיל לאובייקט שקרא לפונקציה זו
         פלט:
            אין
         */
        private void chkbox_HighBlack_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_HighBlack.Checked == true)
            {
                chkbox_HighBlue.Checked = false;
                chkbox_HighRed.Checked = false;
                chkbox_HighGreen.Checked = false;
                chkbox_HighYellow.Checked = false;
                chkbox_HighCyan.Checked = false;
                chkbox_HighPink.Checked = false;
                chkbox_HighWhite.Checked = false;
                chkbox_RandColor.Checked = false;
            }
        }
        private void chkbox_HighBlue_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_HighBlue.Checked == true)
            {
                chkbox_HighBlack.Checked = false;
                chkbox_HighRed.Checked = false;
                chkbox_HighGreen.Checked = false;
                chkbox_HighYellow.Checked = false;
                chkbox_HighCyan.Checked = false;
                chkbox_HighPink.Checked = false;
                chkbox_HighWhite.Checked = false;
                chkbox_RandColor.Checked = false;
            }
        }
        private void chkbox_HighRed_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_HighRed.Checked == true)
            {
                chkbox_HighBlue.Checked = false;
                chkbox_HighBlack.Checked = false;
                chkbox_HighGreen.Checked = false;
                chkbox_HighYellow.Checked = false;
                chkbox_HighCyan.Checked = false;
                chkbox_HighPink.Checked = false;
                chkbox_HighWhite.Checked = false;
                chkbox_RandColor.Checked = false;
            }
        }
        private void chkbox_HighGreen_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_HighGreen.Checked == true)
            {
                chkbox_HighBlue.Checked = false;
                chkbox_HighBlack.Checked = false;
                chkbox_HighRed.Checked = false;
                chkbox_HighYellow.Checked = false;
                chkbox_HighCyan.Checked = false;
                chkbox_HighPink.Checked = false;
                chkbox_HighWhite.Checked = false;
                chkbox_RandColor.Checked = false;
            }
        }
        private void chkbox_HighYellow_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_HighYellow.Checked == true)
            {
                chkbox_HighBlue.Checked = false;
                chkbox_HighBlack.Checked = false;
                chkbox_HighGreen.Checked = false;
                chkbox_HighRed.Checked = false;
                chkbox_HighCyan.Checked = false;
                chkbox_HighPink.Checked = false;
                chkbox_HighWhite.Checked = false;
                chkbox_RandColor.Checked = false;
            }
        }
        private void chkbox_HighCyan_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_HighCyan.Checked == true)
            {
                chkbox_HighBlue.Checked = false;
                chkbox_HighBlack.Checked = false;
                chkbox_HighGreen.Checked = false;
                chkbox_HighYellow.Checked = false;
                chkbox_HighRed.Checked = false;
                chkbox_HighPink.Checked = false;
                chkbox_HighWhite.Checked = false;
                chkbox_RandColor.Checked = false;
            }
        }
        private void chkbox_HighPink_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_HighPink.Checked == true)
            {
                chkbox_HighBlue.Checked = false;
                chkbox_HighBlack.Checked = false;
                chkbox_HighGreen.Checked = false;
                chkbox_HighYellow.Checked = false;
                chkbox_HighCyan.Checked = false;
                chkbox_HighRed.Checked = false;
                chkbox_HighWhite.Checked = false;
                chkbox_RandColor.Checked = false;
            }
        }
        private void chkbox_HighWhite_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_HighWhite.Checked == true)
            {
                chkbox_HighBlue.Checked = false;
                chkbox_HighBlack.Checked = false;
                chkbox_HighGreen.Checked = false;
                chkbox_HighYellow.Checked = false;
                chkbox_HighCyan.Checked = false;
                chkbox_HighPink.Checked = false;
                chkbox_HighRed.Checked = false;
                chkbox_RandColor.Checked = false;
            }
        }
        /**
         .הפונקציות למטה נקראת כאשר משנים את הסימן בתיבה שהיא קשורה אליה
         .התפקיד של כל אחת מהן הוא שכאשר מסמנים אותה להוריד את שאר הסימונים מהתיבות שקשורות לפונקציות האחרות שרשומות כאן
         .מטרתן היא לוודא שנבחר רק צבע אחד בתור צבע לנקודות הנמוכות של הגרף
         קלט:
            EventArgs e - שמכיל את הפרטים של האירוע EventArgs משתנה מסוג
            Object Sender - פרמטר שמכיל לאובייקט שקרא לפונקציה זו
         פלט:
            אין
         */
        private void chkbox_LowBlack_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_LowBlack.Checked == true)
            {
                chkbox_LowBlue.Checked = false;
                chkbox_LowRed.Checked = false;
                chkbox_LowGreen.Checked = false;
                chkbox_LowYellow.Checked = false;
                chkbox_LowCyan.Checked = false;
                chkbox_LowPink.Checked = false;
                chkbox_LowWhite.Checked = false;
                chkbox_RandColor.Checked = false;
            }
        }
        private void chkbox_LowBlue_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_LowBlue.Checked == true)
            {
                chkbox_LowBlack.Checked = false;
                chkbox_LowRed.Checked = false;
                chkbox_LowGreen.Checked = false;
                chkbox_LowYellow.Checked = false;
                chkbox_LowCyan.Checked = false;
                chkbox_LowPink.Checked = false;
                chkbox_LowWhite.Checked = false;
                chkbox_RandColor.Checked = false;
            }
        }
        private void chkbox_LowRed_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_LowRed.Checked == true)
            {
                chkbox_LowBlue.Checked = false;
                chkbox_LowBlack.Checked = false;
                chkbox_LowGreen.Checked = false;
                chkbox_LowYellow.Checked = false;
                chkbox_LowCyan.Checked = false;
                chkbox_LowPink.Checked = false;
                chkbox_LowWhite.Checked = false;
                chkbox_RandColor.Checked = false;
            }
        }
        private void chkbox_LowGreen_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_LowGreen.Checked == true)
            {
                chkbox_LowBlue.Checked = false;
                chkbox_LowRed.Checked = false;
                chkbox_LowBlack.Checked = false;
                chkbox_LowYellow.Checked = false;
                chkbox_LowCyan.Checked = false;
                chkbox_LowPink.Checked = false;
                chkbox_LowWhite.Checked = false;
                chkbox_RandColor.Checked = false;
            }
        }
        private void chkbox_LowYellow_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_LowYellow.Checked == true)
            {
                chkbox_LowBlue.Checked = false;
                chkbox_LowRed.Checked = false;
                chkbox_LowGreen.Checked = false;
                chkbox_LowBlack.Checked = false;
                chkbox_LowCyan.Checked = false;
                chkbox_LowPink.Checked = false;
                chkbox_LowWhite.Checked = false;
                chkbox_RandColor.Checked = false;
            }
        }
        private void chkbox_LowCyan_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_LowCyan.Checked == true)
            {
                chkbox_LowBlue.Checked = false;
                chkbox_LowRed.Checked = false;
                chkbox_LowGreen.Checked = false;
                chkbox_LowYellow.Checked = false;
                chkbox_LowBlack.Checked = false;
                chkbox_LowPink.Checked = false;
                chkbox_LowWhite.Checked = false;
                chkbox_RandColor.Checked = false;
            }
        }
        private void chkbox_LowPink_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_LowPink.Checked == true)
            {
                chkbox_LowBlue.Checked = false;
                chkbox_LowRed.Checked = false;
                chkbox_LowGreen.Checked = false;
                chkbox_LowYellow.Checked = false;
                chkbox_LowCyan.Checked = false;
                chkbox_LowBlack.Checked = false;
                chkbox_LowWhite.Checked = false;
                chkbox_RandColor.Checked = false;
            }
        }
        private void chkbox_LowWhite_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_LowWhite.Checked == true)
            {
                chkbox_LowBlue.Checked = false;
                chkbox_LowRed.Checked = false;
                chkbox_LowGreen.Checked = false;
                chkbox_LowYellow.Checked = false;
                chkbox_LowCyan.Checked = false;
                chkbox_LowPink.Checked = false;
                chkbox_LowBlack.Checked = false;
                chkbox_RandColor.Checked = false;
            }
        }
        /**
         .עומד עליו משתנה combo boxקוראים לפונקציה זו כל פעם שהאינדקס הנוכחי של החפץ שה
         .פונקציה זו אחראית על להקפיץ הודעה למשתמש עם ההגדרות המומלצות לערכים של הצגת הגרף, כאשר הוא בוחר בפונקציה מוכנה מראש
         קלט:
            EventArgs e - שמכיל את הפרטים של האירוע EventArgs משתנה מסוג
            Object Sender - פרמטר שמכיל לאובייקט שקרא לפונקציה זו
         פלט:
            אין
         */
        private void cmbox_Eqation_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbox_Eqation.SelectedIndex)
            {
                case 0:
                    MessageBox.Show(":הגדרות מומלצות\nקיצוניות : 0.6\nרזולוציה : 0.1528"); // x^2+y^2-40
                    break;
                case 1:
                    MessageBox.Show(":הגדרות מומלצות\nקיצוניות : 0.6\nרזולוציה : 0.1528"); // x^2-y^2
                    break;
                case 2:
                    MessageBox.Show(":הגדרות מומלצות\nקיצוניות : 0.15\nרזולוציה : 0.0953"); // x^2*y^2-20
                    break;
                case 3:
                    MessageBox.Show(":הגדרות מומלצות\nקיצוניות : 7\nרזולוציה : 10.4857"); // sin(x)
                    break;
                case 4:
                    MessageBox.Show(":הגדרות מומלצות\nקיצוניות : 6\nרזולוציה : 16.7772"); //  cos(x)+cos(y)^2
                    break;
                case 5:
                    MessageBox.Show(":הגדרות מומלצות\nקיצוניות : 6\nרזולוציה : 0.625"); // cos(x^2+y^2)
                    break;
                case 6:
                    MessageBox.Show(":הגדרות מומלצות\nקיצוניות : 6\nרזולוציה : 0.625"); // sin(x^2+y^2)
                    break;
                case 7:
                    MessageBox.Show(":הגדרות מומלצות\nקיצוניות : 0.05\nטווח ערכים : מ-1 עד 1"); // 1/(x^2+y^2)
                    break;
                case 8:
                    MessageBox.Show(":הגדרות מומלצות\nקיצוניות : 5\nרזולוציה : 6.5536"); // abs(cos(x)+cos(y))^0.5
                    break;
                case 9:
                    MessageBox.Show(":הגדרות מומלצות\nקיצוניות : 3\nרזולוציה : 10.4857"); // cos(x)+cos(y)
                    break;
                case 10:
                    MessageBox.Show(":הגדרות מומלצות\nקיצוניות : 7\nרזולוציה : 0.3906"); // abs(cos(x^2+y^2))^0.5
                    break;
                case 11:
                    MessageBox.Show(":הגדרות מומלצות\nקיצוניות : 5\nרזולוציה : 10.4857"); // abs(cos(x+y))^0.5
                    break;
                case 12:
                    MessageBox.Show(":הגדרות מומלצות\nקיצוניות : 0.05\nרזולוציה : 10.4857"); // cos(abs(x)+abs(y))*(x+y)
                    break;
                case 13:
                    MessageBox.Show(":הגדרות מומלצות\n אפשרות 1 :\n קיצוניות : 0.05\nרזולוציה : 6.5536\n\nאפשרות 2 : \nקיצוניות : 1\nרזולוציה : 1"); // cos(abs(x)+abs(y))*(abs(x)+abs(y))
                    break;
                case 14:
                    MessageBox.Show(":הגדרות מומלצות\nקיצוניות : 7\nרזולוציה : 10.4857"); // cos(abs(x)+abs(y))
                    break;
                case 15:
                    MessageBox.Show(":הגדרות מומלצות\nקיצוניות : 4\nרזולוציה : 6.5536"); // abs(sin(x)*(sin(x)+cos(y)))^0.2
                    break;
                case 16:
                    MessageBox.Show(":הגדרות מומלצות\nקיצוניות : 4\nרזולוציה : 0.625"); // sin(x^2)+cos(y^2)
                    break;
                case 17:
                    MessageBox.Show(":הגדרות מומלצות\nקיצוניות : 0.1\nרזולוציה : 0.0953"); // x*(y^3)-y*(x^3)
                    break;
                case 18:
                    MessageBox.Show(":הגדרות מומלצות\nקיצוניות : 3\nרזולוציה : 0.3906\nz רצוי לסמן הפוך ציר"); // (x^2+y^2)^0.5-15
                    break;
                case 19:
                    MessageBox.Show(":הגדרות מומלצות\nקיצוניות : 3\nרזולוציה : 0.3906\nזום : 3"); // 20-abs(x+y)-abs(y-x)
                    break;
                case 20:
                    MessageBox.Show(":הגדרות מומלצות\nקיצוניות : 4\nרזולוציה : 6.5536"); // abs(sin(x)*(sin(y)+cos(x)))^0.2
                    break;
            }
        }
        /**
         .קוראים לפונקציה זו כל פעם שהסימון של התיבה שמסמנת ליצור משוואה אקראית שתהיה אחראית על צבע הגרף משתנה
         .כאשר תיבה זו מסומנת תפקיד הפונקציה הוא להוריד את הסימון משאר התיבות שקשורות לצבעים
         קלט:
            EventArgs e - שמכיל את הפרטים של האירוע EventArgs משתנה מסוג
            Object Sender - פרמטר שמכיל לאובייקט שקרא לפונקציה זו
         פלט:
            אין
         */
        private void chkbox_RandColor_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_RandColor.Checked == true)
            {
                chkbox_LowBlue.Checked = false;
                chkbox_LowRed.Checked = false;
                chkbox_LowGreen.Checked = false;
                chkbox_LowYellow.Checked = false;
                chkbox_LowCyan.Checked = false;
                chkbox_LowPink.Checked = false;
                chkbox_LowBlack.Checked = false;
                chkbox_LowWhite.Checked = false;
                chkbox_HighBlue.Checked = false;
                chkbox_HighBlack.Checked = false;
                chkbox_HighGreen.Checked = false;
                chkbox_HighYellow.Checked = false;
                chkbox_HighCyan.Checked = false;
                chkbox_HighPink.Checked = false;
                chkbox_HighRed.Checked = false;
                chkbox_HighWhite.Checked = false;
            }
        }
        /**
         יהיה ציר העומק או ציר הגובה zשתי הפונקציות האלו אחראיות על האם ציר ה
         בנוסף הן אחראיות על שיהיה אפשר לסמן רק אחת מהן בכל זמן נתון ושתמיד אחת מהן תהיה מסומנת
         קלט:
            EventArgs e - שמכיל את הפרטים של האירוע EventArgs משתנה מסוג
            Object Sender - פרמטר שמכיל לאובייקט שקרא לפונקציה זו
         פלט:
            אין
         */
        private void chkbox_Height_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_Height.Checked == true)
            {
                chkbox_Depth.Checked = false;
                chkbox_Depth.Enabled = true;
                chkbox_Height.Enabled = false;
            }
        }
        private void chkbox_Depth_CheckedChanged(object sender, EventArgs e)
        {
            if (chkbox_Depth.Checked == true)
            {
                chkbox_Height.Checked = false;
                chkbox_Height.Enabled = true;
                chkbox_Depth.Enabled = false;
            }
        }
    }
}
