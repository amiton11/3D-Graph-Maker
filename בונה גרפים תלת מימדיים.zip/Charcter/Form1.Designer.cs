﻿namespace Graphs
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_BuildGraph = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.trkbar_Sharpness = new System.Windows.Forms.TrackBar();
            this.label3 = new System.Windows.Forms.Label();
            this.trkbar_Size = new System.Windows.Forms.TrackBar();
            this.label4 = new System.Windows.Forms.Label();
            this.trkbar_Zoom = new System.Windows.Forms.TrackBar();
            this.trkbar_Resoulution = new System.Windows.Forms.TrackBar();
            this.label5 = new System.Windows.Forms.Label();
            this.txtbox_Sharpness = new System.Windows.Forms.TextBox();
            this.txtbox_Size = new System.Windows.Forms.TextBox();
            this.txtbox_Zoom = new System.Windows.Forms.TextBox();
            this.txtbox_Resoulution = new System.Windows.Forms.TextBox();
            this.trkbar_XAngle = new System.Windows.Forms.TrackBar();
            this.txtbox_XAngle = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.trkbar_YAngle = new System.Windows.Forms.TrackBar();
            this.txtbox_YAngle = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.chkbox_Lines = new System.Windows.Forms.CheckBox();
            this.trkbar_Lines = new System.Windows.Forms.TrackBar();
            this.txtbox_Lines = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbox_Eqation = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.chkbox_HighBlack = new System.Windows.Forms.CheckBox();
            this.chkbox_HighBlue = new System.Windows.Forms.CheckBox();
            this.chkbox_HighRed = new System.Windows.Forms.CheckBox();
            this.chkbox_HighGreen = new System.Windows.Forms.CheckBox();
            this.chkbox_HighYellow = new System.Windows.Forms.CheckBox();
            this.chkbox_HighCyan = new System.Windows.Forms.CheckBox();
            this.chkbox_HighPink = new System.Windows.Forms.CheckBox();
            this.chkbox_HighWhite = new System.Windows.Forms.CheckBox();
            this.chkbox_LowWhite = new System.Windows.Forms.CheckBox();
            this.chkbox_LowPink = new System.Windows.Forms.CheckBox();
            this.chkbox_LowCyan = new System.Windows.Forms.CheckBox();
            this.chkbox_LowYellow = new System.Windows.Forms.CheckBox();
            this.chkbox_LowGreen = new System.Windows.Forms.CheckBox();
            this.chkbox_LowRed = new System.Windows.Forms.CheckBox();
            this.chkbox_LowBlue = new System.Windows.Forms.CheckBox();
            this.chkbox_LowBlack = new System.Windows.Forms.CheckBox();
            this.chkbox_FlipX = new System.Windows.Forms.CheckBox();
            this.chkbox_FlipY = new System.Windows.Forms.CheckBox();
            this.chkbox_FlipZ = new System.Windows.Forms.CheckBox();
            this.chkbox_SizeRange = new System.Windows.Forms.CheckBox();
            this.txtbox_RangeFrom = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtbox_RangeTo = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.chkbox_Resoulution = new System.Windows.Forms.CheckBox();
            this.chkbox_RandColor = new System.Windows.Forms.CheckBox();
            this.chkbox_ThickLines = new System.Windows.Forms.CheckBox();
            this.chkbox_Height = new System.Windows.Forms.CheckBox();
            this.chkbox_Depth = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.trkbar_Sharpness)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkbar_Size)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkbar_Zoom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkbar_Resoulution)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkbar_XAngle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkbar_YAngle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkbar_Lines)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(830, 573);
            this.panel1.TabIndex = 0;
            // 
            // btn_BuildGraph
            // 
            this.btn_BuildGraph.Location = new System.Drawing.Point(982, 11);
            this.btn_BuildGraph.Name = "btn_BuildGraph";
            this.btn_BuildGraph.Size = new System.Drawing.Size(175, 23);
            this.btn_BuildGraph.TabIndex = 0;
            this.btn_BuildGraph.Text = "בנה גרף על פי משוואה משלך";
            this.btn_BuildGraph.UseVisualStyleBackColor = true;
            this.btn_BuildGraph.Click += new System.EventHandler(this.btn_BuildGraph_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(851, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Z = ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1096, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "קיצוניות";
            // 
            // trkbar_Sharpness
            // 
            this.trkbar_Sharpness.Location = new System.Drawing.Point(899, 103);
            this.trkbar_Sharpness.Maximum = 20;
            this.trkbar_Sharpness.Minimum = -18;
            this.trkbar_Sharpness.Name = "trkbar_Sharpness";
            this.trkbar_Sharpness.Size = new System.Drawing.Size(190, 45);
            this.trkbar_Sharpness.TabIndex = 4;
            this.trkbar_Sharpness.Value = 1;
            this.trkbar_Sharpness.Scroll += new System.EventHandler(this.trkbar_Sharpness_Scroll);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1117, 157);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "גודל";
            // 
            // trkbar_Size
            // 
            this.trkbar_Size.Location = new System.Drawing.Point(900, 154);
            this.trkbar_Size.Maximum = 300;
            this.trkbar_Size.Minimum = 10;
            this.trkbar_Size.Name = "trkbar_Size";
            this.trkbar_Size.Size = new System.Drawing.Size(211, 45);
            this.trkbar_Size.TabIndex = 6;
            this.trkbar_Size.TickFrequency = 10;
            this.trkbar_Size.Value = 100;
            this.trkbar_Size.Scroll += new System.EventHandler(this.trkbar_Size_Scroll);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1117, 208);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "zoom";
            // 
            // trkbar_Zoom
            // 
            this.trkbar_Zoom.LargeChange = 3;
            this.trkbar_Zoom.Location = new System.Drawing.Point(899, 205);
            this.trkbar_Zoom.Maximum = 12;
            this.trkbar_Zoom.Minimum = -1;
            this.trkbar_Zoom.Name = "trkbar_Zoom";
            this.trkbar_Zoom.Size = new System.Drawing.Size(211, 45);
            this.trkbar_Zoom.TabIndex = 8;
            this.trkbar_Zoom.Value = 5;
            this.trkbar_Zoom.Scroll += new System.EventHandler(this.trkbar_Zoom_Scroll);
            // 
            // trkbar_Resoulution
            // 
            this.trkbar_Resoulution.Location = new System.Drawing.Point(906, 256);
            this.trkbar_Resoulution.Maximum = 8;
            this.trkbar_Resoulution.Minimum = -7;
            this.trkbar_Resoulution.Name = "trkbar_Resoulution";
            this.trkbar_Resoulution.Size = new System.Drawing.Size(86, 45);
            this.trkbar_Resoulution.TabIndex = 9;
            this.trkbar_Resoulution.Scroll += new System.EventHandler(this.trkbar_Resoulution_Scroll);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(984, 259);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "רזולוציה";
            // 
            // txtbox_Sharpness
            // 
            this.txtbox_Sharpness.Location = new System.Drawing.Point(851, 103);
            this.txtbox_Sharpness.Name = "txtbox_Sharpness";
            this.txtbox_Sharpness.ReadOnly = true;
            this.txtbox_Sharpness.Size = new System.Drawing.Size(43, 20);
            this.txtbox_Sharpness.TabIndex = 11;
            this.txtbox_Sharpness.Text = "1";
            this.txtbox_Sharpness.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbox_Size
            // 
            this.txtbox_Size.Location = new System.Drawing.Point(851, 154);
            this.txtbox_Size.Name = "txtbox_Size";
            this.txtbox_Size.ReadOnly = true;
            this.txtbox_Size.Size = new System.Drawing.Size(43, 20);
            this.txtbox_Size.TabIndex = 12;
            this.txtbox_Size.Text = "100";
            this.txtbox_Size.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbox_Zoom
            // 
            this.txtbox_Zoom.Location = new System.Drawing.Point(851, 205);
            this.txtbox_Zoom.Name = "txtbox_Zoom";
            this.txtbox_Zoom.ReadOnly = true;
            this.txtbox_Zoom.Size = new System.Drawing.Size(43, 20);
            this.txtbox_Zoom.TabIndex = 13;
            this.txtbox_Zoom.Text = "5";
            this.txtbox_Zoom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtbox_Resoulution
            // 
            this.txtbox_Resoulution.Location = new System.Drawing.Point(851, 256);
            this.txtbox_Resoulution.Name = "txtbox_Resoulution";
            this.txtbox_Resoulution.ReadOnly = true;
            this.txtbox_Resoulution.Size = new System.Drawing.Size(55, 20);
            this.txtbox_Resoulution.TabIndex = 14;
            this.txtbox_Resoulution.Text = "1";
            this.txtbox_Resoulution.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // trkbar_XAngle
            // 
            this.trkbar_XAngle.Location = new System.Drawing.Point(900, 307);
            this.trkbar_XAngle.Maximum = 90;
            this.trkbar_XAngle.Name = "trkbar_XAngle";
            this.trkbar_XAngle.Size = new System.Drawing.Size(199, 45);
            this.trkbar_XAngle.TabIndex = 15;
            this.trkbar_XAngle.TickFrequency = 5;
            this.trkbar_XAngle.Value = 60;
            this.trkbar_XAngle.Scroll += new System.EventHandler(this.trkbar_XAngle_Scroll);
            // 
            // txtbox_XAngle
            // 
            this.txtbox_XAngle.Location = new System.Drawing.Point(851, 310);
            this.txtbox_XAngle.Name = "txtbox_XAngle";
            this.txtbox_XAngle.ReadOnly = true;
            this.txtbox_XAngle.Size = new System.Drawing.Size(43, 20);
            this.txtbox_XAngle.TabIndex = 16;
            this.txtbox_XAngle.Text = "60";
            this.txtbox_XAngle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1105, 313);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "X זווית";
            // 
            // trkbar_YAngle
            // 
            this.trkbar_YAngle.Location = new System.Drawing.Point(900, 358);
            this.trkbar_YAngle.Maximum = 90;
            this.trkbar_YAngle.Name = "trkbar_YAngle";
            this.trkbar_YAngle.Size = new System.Drawing.Size(199, 45);
            this.trkbar_YAngle.TabIndex = 18;
            this.trkbar_YAngle.TickFrequency = 5;
            this.trkbar_YAngle.Value = 60;
            this.trkbar_YAngle.Scroll += new System.EventHandler(this.trkbar_YAngle_Scroll);
            // 
            // txtbox_YAngle
            // 
            this.txtbox_YAngle.Location = new System.Drawing.Point(851, 358);
            this.txtbox_YAngle.Name = "txtbox_YAngle";
            this.txtbox_YAngle.ReadOnly = true;
            this.txtbox_YAngle.Size = new System.Drawing.Size(43, 20);
            this.txtbox_YAngle.TabIndex = 19;
            this.txtbox_YAngle.Text = "60";
            this.txtbox_YAngle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1105, 361);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 13);
            this.label7.TabIndex = 20;
            this.label7.Text = "Y זווית";
            // 
            // chkbox_Lines
            // 
            this.chkbox_Lines.AutoSize = true;
            this.chkbox_Lines.Location = new System.Drawing.Point(901, 14);
            this.chkbox_Lines.Name = "chkbox_Lines";
            this.chkbox_Lines.Size = new System.Drawing.Size(86, 17);
            this.chkbox_Lines.TabIndex = 21;
            this.chkbox_Lines.Text = "?רשת קווים";
            this.chkbox_Lines.UseVisualStyleBackColor = true;
            this.chkbox_Lines.CheckedChanged += new System.EventHandler(this.chkbox_Lines_CheckedChanged);
            // 
            // trkbar_Lines
            // 
            this.trkbar_Lines.Enabled = false;
            this.trkbar_Lines.Location = new System.Drawing.Point(899, 37);
            this.trkbar_Lines.Maximum = 49;
            this.trkbar_Lines.Name = "trkbar_Lines";
            this.trkbar_Lines.Size = new System.Drawing.Size(158, 45);
            this.trkbar_Lines.TabIndex = 22;
            this.trkbar_Lines.TickFrequency = 5;
            this.trkbar_Lines.Value = 40;
            this.trkbar_Lines.Scroll += new System.EventHandler(this.trkbar_Lines_Scroll);
            // 
            // txtbox_Lines
            // 
            this.txtbox_Lines.Location = new System.Drawing.Point(851, 39);
            this.txtbox_Lines.Name = "txtbox_Lines";
            this.txtbox_Lines.ReadOnly = true;
            this.txtbox_Lines.Size = new System.Drawing.Size(43, 20);
            this.txtbox_Lines.TabIndex = 23;
            this.txtbox_Lines.Text = "10";
            this.txtbox_Lines.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1063, 42);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 13);
            this.label8.TabIndex = 24;
            this.label8.Text = "תכיפות קווים";
            // 
            // cmbox_Eqation
            // 
            this.cmbox_Eqation.FormattingEnabled = true;
            this.cmbox_Eqation.Location = new System.Drawing.Point(883, 72);
            this.cmbox_Eqation.Name = "cmbox_Eqation";
            this.cmbox_Eqation.Size = new System.Drawing.Size(265, 21);
            this.cmbox_Eqation.TabIndex = 25;
            this.cmbox_Eqation.SelectedIndexChanged += new System.EventHandler(this.cmbox_Eqation_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label9.Location = new System.Drawing.Point(1054, 436);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 13);
            this.label9.TabIndex = 26;
            this.label9.Text = "צבע - גבוה";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label10.Location = new System.Drawing.Point(884, 436);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(71, 13);
            this.label10.TabIndex = 27;
            this.label10.Text = "צבע - נמוך";
            // 
            // chkbox_HighBlack
            // 
            this.chkbox_HighBlack.AutoSize = true;
            this.chkbox_HighBlack.Location = new System.Drawing.Point(1092, 453);
            this.chkbox_HighBlack.Name = "chkbox_HighBlack";
            this.chkbox_HighBlack.Size = new System.Drawing.Size(53, 17);
            this.chkbox_HighBlack.TabIndex = 28;
            this.chkbox_HighBlack.Text = "שחור";
            this.chkbox_HighBlack.UseVisualStyleBackColor = true;
            this.chkbox_HighBlack.CheckedChanged += new System.EventHandler(this.chkbox_HighBlack_CheckedChanged);
            // 
            // chkbox_HighBlue
            // 
            this.chkbox_HighBlue.AutoSize = true;
            this.chkbox_HighBlue.Location = new System.Drawing.Point(1092, 476);
            this.chkbox_HighBlue.Name = "chkbox_HighBlue";
            this.chkbox_HighBlue.Size = new System.Drawing.Size(52, 17);
            this.chkbox_HighBlue.TabIndex = 29;
            this.chkbox_HighBlue.Text = "כחול";
            this.chkbox_HighBlue.UseVisualStyleBackColor = true;
            this.chkbox_HighBlue.CheckedChanged += new System.EventHandler(this.chkbox_HighBlue_CheckedChanged);
            // 
            // chkbox_HighRed
            // 
            this.chkbox_HighRed.AutoSize = true;
            this.chkbox_HighRed.Location = new System.Drawing.Point(1092, 499);
            this.chkbox_HighRed.Name = "chkbox_HighRed";
            this.chkbox_HighRed.Size = new System.Drawing.Size(53, 17);
            this.chkbox_HighRed.TabIndex = 30;
            this.chkbox_HighRed.Text = "אדום";
            this.chkbox_HighRed.UseVisualStyleBackColor = true;
            this.chkbox_HighRed.CheckedChanged += new System.EventHandler(this.chkbox_HighRed_CheckedChanged);
            // 
            // chkbox_HighGreen
            // 
            this.chkbox_HighGreen.AutoSize = true;
            this.chkbox_HighGreen.Location = new System.Drawing.Point(1092, 522);
            this.chkbox_HighGreen.Name = "chkbox_HighGreen";
            this.chkbox_HighGreen.Size = new System.Drawing.Size(49, 17);
            this.chkbox_HighGreen.TabIndex = 31;
            this.chkbox_HighGreen.Text = "ירוק";
            this.chkbox_HighGreen.UseVisualStyleBackColor = true;
            this.chkbox_HighGreen.CheckedChanged += new System.EventHandler(this.chkbox_HighGreen_CheckedChanged);
            // 
            // chkbox_HighYellow
            // 
            this.chkbox_HighYellow.AutoSize = true;
            this.chkbox_HighYellow.Location = new System.Drawing.Point(1031, 453);
            this.chkbox_HighYellow.Name = "chkbox_HighYellow";
            this.chkbox_HighYellow.Size = new System.Drawing.Size(52, 17);
            this.chkbox_HighYellow.TabIndex = 32;
            this.chkbox_HighYellow.Text = "צהוב";
            this.chkbox_HighYellow.UseVisualStyleBackColor = true;
            this.chkbox_HighYellow.CheckedChanged += new System.EventHandler(this.chkbox_HighYellow_CheckedChanged);
            // 
            // chkbox_HighCyan
            // 
            this.chkbox_HighCyan.AutoSize = true;
            this.chkbox_HighCyan.Location = new System.Drawing.Point(1031, 476);
            this.chkbox_HighCyan.Name = "chkbox_HighCyan";
            this.chkbox_HighCyan.Size = new System.Drawing.Size(54, 17);
            this.chkbox_HighCyan.TabIndex = 33;
            this.chkbox_HighCyan.Text = "תכלת";
            this.chkbox_HighCyan.UseVisualStyleBackColor = true;
            this.chkbox_HighCyan.CheckedChanged += new System.EventHandler(this.chkbox_HighCyan_CheckedChanged);
            // 
            // chkbox_HighPink
            // 
            this.chkbox_HighPink.AutoSize = true;
            this.chkbox_HighPink.Location = new System.Drawing.Point(1031, 499);
            this.chkbox_HighPink.Name = "chkbox_HighPink";
            this.chkbox_HighPink.Size = new System.Drawing.Size(49, 17);
            this.chkbox_HighPink.TabIndex = 34;
            this.chkbox_HighPink.Text = "ורוד";
            this.chkbox_HighPink.UseVisualStyleBackColor = true;
            this.chkbox_HighPink.CheckedChanged += new System.EventHandler(this.chkbox_HighPink_CheckedChanged);
            // 
            // chkbox_HighWhite
            // 
            this.chkbox_HighWhite.AutoSize = true;
            this.chkbox_HighWhite.Location = new System.Drawing.Point(1031, 522);
            this.chkbox_HighWhite.Name = "chkbox_HighWhite";
            this.chkbox_HighWhite.Size = new System.Drawing.Size(45, 17);
            this.chkbox_HighWhite.TabIndex = 35;
            this.chkbox_HighWhite.Text = "לבן";
            this.chkbox_HighWhite.UseVisualStyleBackColor = true;
            this.chkbox_HighWhite.CheckedChanged += new System.EventHandler(this.chkbox_HighWhite_CheckedChanged);
            // 
            // chkbox_LowWhite
            // 
            this.chkbox_LowWhite.AutoSize = true;
            this.chkbox_LowWhite.Location = new System.Drawing.Point(865, 521);
            this.chkbox_LowWhite.Name = "chkbox_LowWhite";
            this.chkbox_LowWhite.Size = new System.Drawing.Size(45, 17);
            this.chkbox_LowWhite.TabIndex = 43;
            this.chkbox_LowWhite.Text = "לבן";
            this.chkbox_LowWhite.UseVisualStyleBackColor = true;
            this.chkbox_LowWhite.CheckedChanged += new System.EventHandler(this.chkbox_LowWhite_CheckedChanged);
            // 
            // chkbox_LowPink
            // 
            this.chkbox_LowPink.AutoSize = true;
            this.chkbox_LowPink.Location = new System.Drawing.Point(865, 498);
            this.chkbox_LowPink.Name = "chkbox_LowPink";
            this.chkbox_LowPink.Size = new System.Drawing.Size(49, 17);
            this.chkbox_LowPink.TabIndex = 42;
            this.chkbox_LowPink.Text = "ורוד";
            this.chkbox_LowPink.UseVisualStyleBackColor = true;
            this.chkbox_LowPink.CheckedChanged += new System.EventHandler(this.chkbox_LowPink_CheckedChanged);
            // 
            // chkbox_LowCyan
            // 
            this.chkbox_LowCyan.AutoSize = true;
            this.chkbox_LowCyan.Location = new System.Drawing.Point(865, 475);
            this.chkbox_LowCyan.Name = "chkbox_LowCyan";
            this.chkbox_LowCyan.Size = new System.Drawing.Size(54, 17);
            this.chkbox_LowCyan.TabIndex = 41;
            this.chkbox_LowCyan.Text = "תכלת";
            this.chkbox_LowCyan.UseVisualStyleBackColor = true;
            this.chkbox_LowCyan.CheckedChanged += new System.EventHandler(this.chkbox_LowCyan_CheckedChanged);
            // 
            // chkbox_LowYellow
            // 
            this.chkbox_LowYellow.AutoSize = true;
            this.chkbox_LowYellow.Location = new System.Drawing.Point(865, 452);
            this.chkbox_LowYellow.Name = "chkbox_LowYellow";
            this.chkbox_LowYellow.Size = new System.Drawing.Size(52, 17);
            this.chkbox_LowYellow.TabIndex = 40;
            this.chkbox_LowYellow.Text = "צהוב";
            this.chkbox_LowYellow.UseVisualStyleBackColor = true;
            this.chkbox_LowYellow.CheckedChanged += new System.EventHandler(this.chkbox_LowYellow_CheckedChanged);
            // 
            // chkbox_LowGreen
            // 
            this.chkbox_LowGreen.AutoSize = true;
            this.chkbox_LowGreen.Location = new System.Drawing.Point(926, 521);
            this.chkbox_LowGreen.Name = "chkbox_LowGreen";
            this.chkbox_LowGreen.Size = new System.Drawing.Size(49, 17);
            this.chkbox_LowGreen.TabIndex = 39;
            this.chkbox_LowGreen.Text = "ירוק";
            this.chkbox_LowGreen.UseVisualStyleBackColor = true;
            this.chkbox_LowGreen.CheckedChanged += new System.EventHandler(this.chkbox_LowGreen_CheckedChanged);
            // 
            // chkbox_LowRed
            // 
            this.chkbox_LowRed.AutoSize = true;
            this.chkbox_LowRed.Location = new System.Drawing.Point(926, 498);
            this.chkbox_LowRed.Name = "chkbox_LowRed";
            this.chkbox_LowRed.Size = new System.Drawing.Size(53, 17);
            this.chkbox_LowRed.TabIndex = 38;
            this.chkbox_LowRed.Text = "אדום";
            this.chkbox_LowRed.UseVisualStyleBackColor = true;
            this.chkbox_LowRed.CheckedChanged += new System.EventHandler(this.chkbox_LowRed_CheckedChanged);
            // 
            // chkbox_LowBlue
            // 
            this.chkbox_LowBlue.AutoSize = true;
            this.chkbox_LowBlue.Location = new System.Drawing.Point(926, 475);
            this.chkbox_LowBlue.Name = "chkbox_LowBlue";
            this.chkbox_LowBlue.Size = new System.Drawing.Size(52, 17);
            this.chkbox_LowBlue.TabIndex = 37;
            this.chkbox_LowBlue.Text = "כחול";
            this.chkbox_LowBlue.UseVisualStyleBackColor = true;
            this.chkbox_LowBlue.CheckedChanged += new System.EventHandler(this.chkbox_LowBlue_CheckedChanged);
            // 
            // chkbox_LowBlack
            // 
            this.chkbox_LowBlack.AutoSize = true;
            this.chkbox_LowBlack.Location = new System.Drawing.Point(926, 452);
            this.chkbox_LowBlack.Name = "chkbox_LowBlack";
            this.chkbox_LowBlack.Size = new System.Drawing.Size(53, 17);
            this.chkbox_LowBlack.TabIndex = 36;
            this.chkbox_LowBlack.Text = "שחור";
            this.chkbox_LowBlack.UseVisualStyleBackColor = true;
            this.chkbox_LowBlack.CheckedChanged += new System.EventHandler(this.chkbox_LowBlack_CheckedChanged);
            // 
            // chkbox_FlipX
            // 
            this.chkbox_FlipX.AutoSize = true;
            this.chkbox_FlipX.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.chkbox_FlipX.Location = new System.Drawing.Point(848, 384);
            this.chkbox_FlipX.Name = "chkbox_FlipX";
            this.chkbox_FlipX.Size = new System.Drawing.Size(96, 22);
            this.chkbox_FlipX.TabIndex = 44;
            this.chkbox_FlipX.Text = "X הפוך ציר";
            this.chkbox_FlipX.UseVisualStyleBackColor = true;
            // 
            // chkbox_FlipY
            // 
            this.chkbox_FlipY.AutoSize = true;
            this.chkbox_FlipY.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.chkbox_FlipY.Location = new System.Drawing.Point(950, 384);
            this.chkbox_FlipY.Name = "chkbox_FlipY";
            this.chkbox_FlipY.Size = new System.Drawing.Size(95, 22);
            this.chkbox_FlipY.TabIndex = 45;
            this.chkbox_FlipY.Text = "Y הפוך ציר";
            this.chkbox_FlipY.UseVisualStyleBackColor = true;
            // 
            // chkbox_FlipZ
            // 
            this.chkbox_FlipZ.AutoSize = true;
            this.chkbox_FlipZ.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.chkbox_FlipZ.Location = new System.Drawing.Point(1053, 384);
            this.chkbox_FlipZ.Name = "chkbox_FlipZ";
            this.chkbox_FlipZ.Size = new System.Drawing.Size(95, 22);
            this.chkbox_FlipZ.TabIndex = 46;
            this.chkbox_FlipZ.Text = "Z הפוך ציר";
            this.chkbox_FlipZ.UseVisualStyleBackColor = true;
            // 
            // chkbox_SizeRange
            // 
            this.chkbox_SizeRange.AutoSize = true;
            this.chkbox_SizeRange.Enabled = false;
            this.chkbox_SizeRange.Location = new System.Drawing.Point(1061, 282);
            this.chkbox_SizeRange.Name = "chkbox_SizeRange";
            this.chkbox_SizeRange.Size = new System.Drawing.Size(85, 17);
            this.chkbox_SizeRange.TabIndex = 47;
            this.chkbox_SizeRange.Text = "טווח ערכים";
            this.chkbox_SizeRange.UseVisualStyleBackColor = true;
            this.chkbox_SizeRange.CheckedChanged += new System.EventHandler(this.chkbox_SizeRange_CheckedChanged);
            // 
            // txtbox_RangeFrom
            // 
            this.txtbox_RangeFrom.Enabled = false;
            this.txtbox_RangeFrom.Location = new System.Drawing.Point(1102, 256);
            this.txtbox_RangeFrom.Name = "txtbox_RangeFrom";
            this.txtbox_RangeFrom.Size = new System.Drawing.Size(33, 20);
            this.txtbox_RangeFrom.TabIndex = 48;
            this.txtbox_RangeFrom.Text = "-50";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(1135, 259);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(14, 13);
            this.label11.TabIndex = 49;
            this.label11.Text = "מ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1081, 259);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(21, 13);
            this.label12.TabIndex = 50;
            this.label12.Text = "עד";
            // 
            // txtbox_RangeTo
            // 
            this.txtbox_RangeTo.Enabled = false;
            this.txtbox_RangeTo.Location = new System.Drawing.Point(1049, 256);
            this.txtbox_RangeTo.Name = "txtbox_RangeTo";
            this.txtbox_RangeTo.Size = new System.Drawing.Size(33, 20);
            this.txtbox_RangeTo.TabIndex = 51;
            this.txtbox_RangeTo.Text = "49";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.label13.Location = new System.Drawing.Point(1033, 254);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(16, 22);
            this.label13.TabIndex = 52;
            this.label13.Text = "|";
            // 
            // chkbox_Resoulution
            // 
            this.chkbox_Resoulution.AutoSize = true;
            this.chkbox_Resoulution.Enabled = false;
            this.chkbox_Resoulution.Location = new System.Drawing.Point(981, 282);
            this.chkbox_Resoulution.Name = "chkbox_Resoulution";
            this.chkbox_Resoulution.Size = new System.Drawing.Size(73, 17);
            this.chkbox_Resoulution.TabIndex = 53;
            this.chkbox_Resoulution.Text = "רזולוציה";
            this.chkbox_Resoulution.UseVisualStyleBackColor = true;
            this.chkbox_Resoulution.CheckedChanged += new System.EventHandler(this.chkbox_Resoulution_CheckedChanged);
            // 
            // chkbox_RandColor
            // 
            this.chkbox_RandColor.AutoSize = true;
            this.chkbox_RandColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.chkbox_RandColor.Location = new System.Drawing.Point(958, 412);
            this.chkbox_RandColor.Name = "chkbox_RandColor";
            this.chkbox_RandColor.Size = new System.Drawing.Size(99, 21);
            this.chkbox_RandColor.TabIndex = 54;
            this.chkbox_RandColor.Text = "צבע אקראי";
            this.chkbox_RandColor.UseVisualStyleBackColor = true;
            this.chkbox_RandColor.CheckedChanged += new System.EventHandler(this.chkbox_RandColor_CheckedChanged);
            // 
            // chkbox_ThickLines
            // 
            this.chkbox_ThickLines.AutoSize = true;
            this.chkbox_ThickLines.Enabled = false;
            this.chkbox_ThickLines.Location = new System.Drawing.Point(843, 14);
            this.chkbox_ThickLines.Name = "chkbox_ThickLines";
            this.chkbox_ThickLines.Size = new System.Drawing.Size(58, 17);
            this.chkbox_ThickLines.TabIndex = 55;
            this.chkbox_ThickLines.Text = "?עבים";
            this.chkbox_ThickLines.UseVisualStyleBackColor = true;
            // 
            // chkbox_Height
            // 
            this.chkbox_Height.AutoSize = true;
            this.chkbox_Height.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.chkbox_Height.Location = new System.Drawing.Point(867, 560);
            this.chkbox_Height.Name = "chkbox_Height";
            this.chkbox_Height.Size = new System.Drawing.Size(111, 22);
            this.chkbox_Height.TabIndex = 56;
            this.chkbox_Height.Text = "גובה -  Z ציר ";
            this.chkbox_Height.UseVisualStyleBackColor = true;
            this.chkbox_Height.CheckedChanged += new System.EventHandler(this.chkbox_Height_CheckedChanged);
            // 
            // chkbox_Depth
            // 
            this.chkbox_Depth.AutoSize = true;
            this.chkbox_Depth.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.chkbox_Depth.Location = new System.Drawing.Point(1031, 560);
            this.chkbox_Depth.Name = "chkbox_Depth";
            this.chkbox_Depth.Size = new System.Drawing.Size(113, 22);
            this.chkbox_Depth.TabIndex = 57;
            this.chkbox_Depth.Text = "עומק -  Z ציר ";
            this.chkbox_Depth.UseVisualStyleBackColor = true;
            this.chkbox_Depth.CheckedChanged += new System.EventHandler(this.chkbox_Depth_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1166, 597);
            this.Controls.Add(this.chkbox_Depth);
            this.Controls.Add(this.chkbox_Height);
            this.Controls.Add(this.chkbox_ThickLines);
            this.Controls.Add(this.txtbox_Lines);
            this.Controls.Add(this.chkbox_RandColor);
            this.Controls.Add(this.chkbox_Resoulution);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtbox_RangeTo);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txtbox_RangeFrom);
            this.Controls.Add(this.chkbox_SizeRange);
            this.Controls.Add(this.chkbox_FlipZ);
            this.Controls.Add(this.chkbox_FlipY);
            this.Controls.Add(this.chkbox_FlipX);
            this.Controls.Add(this.chkbox_LowWhite);
            this.Controls.Add(this.chkbox_LowPink);
            this.Controls.Add(this.chkbox_LowCyan);
            this.Controls.Add(this.chkbox_LowYellow);
            this.Controls.Add(this.chkbox_LowGreen);
            this.Controls.Add(this.chkbox_LowRed);
            this.Controls.Add(this.chkbox_LowBlue);
            this.Controls.Add(this.chkbox_LowBlack);
            this.Controls.Add(this.chkbox_HighWhite);
            this.Controls.Add(this.chkbox_HighPink);
            this.Controls.Add(this.chkbox_HighCyan);
            this.Controls.Add(this.chkbox_HighYellow);
            this.Controls.Add(this.chkbox_HighGreen);
            this.Controls.Add(this.chkbox_HighRed);
            this.Controls.Add(this.chkbox_HighBlue);
            this.Controls.Add(this.chkbox_HighBlack);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.cmbox_Eqation);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btn_BuildGraph);
            this.Controls.Add(this.chkbox_Lines);
            this.Controls.Add(this.trkbar_Lines);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtbox_YAngle);
            this.Controls.Add(this.trkbar_YAngle);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtbox_XAngle);
            this.Controls.Add(this.trkbar_XAngle);
            this.Controls.Add(this.txtbox_Resoulution);
            this.Controls.Add(this.txtbox_Zoom);
            this.Controls.Add(this.txtbox_Size);
            this.Controls.Add(this.txtbox_Sharpness);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.trkbar_Resoulution);
            this.Controls.Add(this.trkbar_Zoom);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.trkbar_Size);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.trkbar_Sharpness);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "בונה הגרפים";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.trkbar_Sharpness)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkbar_Size)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkbar_Zoom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkbar_Resoulution)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkbar_XAngle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkbar_YAngle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trkbar_Lines)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_BuildGraph;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TrackBar trkbar_Sharpness;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TrackBar trkbar_Size;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TrackBar trkbar_Zoom;
        private System.Windows.Forms.TrackBar trkbar_Resoulution;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtbox_Sharpness;
        private System.Windows.Forms.TextBox txtbox_Size;
        private System.Windows.Forms.TextBox txtbox_Zoom;
        private System.Windows.Forms.TextBox txtbox_Resoulution;
        private System.Windows.Forms.TrackBar trkbar_XAngle;
        private System.Windows.Forms.TextBox txtbox_XAngle;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TrackBar trkbar_YAngle;
        private System.Windows.Forms.TextBox txtbox_YAngle;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox chkbox_Lines;
        private System.Windows.Forms.TrackBar trkbar_Lines;
        private System.Windows.Forms.TextBox txtbox_Lines;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbox_Eqation;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox chkbox_HighBlack;
        private System.Windows.Forms.CheckBox chkbox_HighBlue;
        private System.Windows.Forms.CheckBox chkbox_HighRed;
        private System.Windows.Forms.CheckBox chkbox_HighGreen;
        private System.Windows.Forms.CheckBox chkbox_HighYellow;
        private System.Windows.Forms.CheckBox chkbox_HighCyan;
        private System.Windows.Forms.CheckBox chkbox_HighPink;
        private System.Windows.Forms.CheckBox chkbox_HighWhite;
        private System.Windows.Forms.CheckBox chkbox_LowWhite;
        private System.Windows.Forms.CheckBox chkbox_LowPink;
        private System.Windows.Forms.CheckBox chkbox_LowCyan;
        private System.Windows.Forms.CheckBox chkbox_LowYellow;
        private System.Windows.Forms.CheckBox chkbox_LowGreen;
        private System.Windows.Forms.CheckBox chkbox_LowRed;
        private System.Windows.Forms.CheckBox chkbox_LowBlue;
        private System.Windows.Forms.CheckBox chkbox_LowBlack;
        private System.Windows.Forms.CheckBox chkbox_FlipX;
        private System.Windows.Forms.CheckBox chkbox_FlipY;
        private System.Windows.Forms.CheckBox chkbox_FlipZ;
        private System.Windows.Forms.CheckBox chkbox_SizeRange;
        private System.Windows.Forms.TextBox txtbox_RangeFrom;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtbox_RangeTo;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.CheckBox chkbox_Resoulution;
        private System.Windows.Forms.CheckBox chkbox_RandColor;
        private System.Windows.Forms.CheckBox chkbox_ThickLines;
        private System.Windows.Forms.CheckBox chkbox_Height;
        private System.Windows.Forms.CheckBox chkbox_Depth;
    }
}

